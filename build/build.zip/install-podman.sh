#!/usr/bin/env bash
# 2025021001

set -e -x

sudo apt update
sudo apt -y install podman
